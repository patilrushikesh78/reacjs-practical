// reducer.js
const INITIAL_STATE = {
  data: {},
  tab: "Home",
};
export default (state = INITIAL_STATE, action :any) => {
  switch (action.type) {
    default:
      return state;
  }
};
