export interface ITab {
  id: number;
  name: string;
  serach: string;
  category: string;
  brand: string;
  minPrice: number;
  maxPrice: number;
  minDiscount: number;
  maxDiscount: number;
}
