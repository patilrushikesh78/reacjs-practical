export interface IProduct {
  categoryName: string;
  brandName: string;
  productName: string;
  image: string;
  price: number;
  rating: number;
  discount: number;
}