export interface IBrand {
  id: number;
  name: string;
  cat_id: number;
}
