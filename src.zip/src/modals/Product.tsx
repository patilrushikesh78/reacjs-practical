export interface Product {
  image: string;
  price: number;
  rating: number;
  discount: number;
}
